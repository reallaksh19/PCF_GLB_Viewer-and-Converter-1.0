/**
 * js/hud/hud-contract.js
 * Defines interaction boundaries for HUD overlays.
 */

export const HUD_MODES = {
  IDLE: 'idle',
  LINE_DRAW: 'line_draw',
  INSERT: 'insert'
};

export const HUD_CONTRACT_VERSION = 1;
