/**
 * js/macro/macro-ir-contract.js
 * Defines the intermediate representation for macros.
 */

export const MACRO_IR_VERSION = 1;

/**
 * Macro IR Contract Example:
 * {
 *   version: 1,
 *   commands: [
 *     { type: 'ROUTE_START', payload: { x: 0, y: 0, z: 0, spec: 'CS150' } },
 *     { type: 'ROUTE_SEGMENT_ADD', payload: { dx: 5000, dy: 0, dz: 0 } },
 *     { type: 'INSERT_COMPONENT', payload: { component: 'VALVE', rating: '150', size: '6' } }
 *   ]
 * }
 */
