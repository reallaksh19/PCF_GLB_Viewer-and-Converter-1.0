/**
 * js/data/masterdb-contract.js
 * Defines the schema and resolver query shapes for the Master DB.
 */

export const MASTERDB_CONTRACT_VERSION = 1;

/**
 * Normalized Internal Record Example:
 * {
 *   id: 'rec-001',
 *   component: 'VALVE',
 *   subtype: 'GATE',
 *   size: '6',
 *   sizeMm: 168.275,
 *   rating: '150',
 *   schedule: null,
 *   facing: 'RF',
 *   endType: 'FLANGED',
 *   length: 292,
 *   weight: 84.5,
 *   branchSize: null,
 *   standard: 'ASME B16.10',
 *   source: 'user-masterdb'
 * }
 */

/**
 * Resolver Result Contract Example:
 * {
 *   ok: true,
 *   source: 'master-db',
 *   matchKey: 'VALVE|GATE|150|6',
 *   resolved: { ...normalized_record },
 *   alternatives: []
 * }
 */
