/**
 * js/editor/route-contract.js
 * Defines the contract for canonical routing state.
 */

export const ROUTE_CONTRACT_VERSION = 1;

/**
 * Example Route Segment Contract
 * {
 *   id: string,
 *   type: 'PIPE' | 'ELBOW' | 'VALVE' ...,
 *   spec: string,
 *   size: string,
 *   rating: string,
 *   geometry: { ep1: {x,y,z}, ep2: {x,y,z} },
 *   attributes: object
 * }
 */
