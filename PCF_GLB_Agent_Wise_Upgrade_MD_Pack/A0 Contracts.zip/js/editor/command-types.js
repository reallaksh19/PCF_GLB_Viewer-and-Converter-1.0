/**
 * js/editor/command-types.js
 * Contract for the command envelope and shared command execution types.
 */

/**
 * Creates a standard command envelope.
 * @param {string} type - The command type (e.g. 'ROUTE_START').
 * @param {object} payload - Command specific payload.
 * @param {object} [meta] - Metadata.
 * @returns {object} The command envelope.
 */
export function createCommand(type, payload, meta = {}) {
  return {
    id: crypto.randomUUID(),
    type,
    payload,
    meta: {
      ts: Date.now(),
      source: meta.source || 'ui',
      ...meta,
    },
  };
}

export const COMMAND_TYPES = {
  ROUTE_START: 'ROUTE_START',
  ROUTE_SEGMENT_ADD: 'ROUTE_SEGMENT_ADD',
  INSERT_COMPONENT: 'INSERT_COMPONENT',
  MOVE_NODE: 'MOVE_NODE',
  DELETE_COMPONENT: 'DELETE_COMPONENT',
  SET_SPEC: 'SET_SPEC'
};
