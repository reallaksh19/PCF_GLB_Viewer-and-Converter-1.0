import { createModelExchangeStore } from '../interchange/state/model-exchange-store.js';
import { importIntoModelExchange, updateViewState } from '../interchange/state/model-exchange-actions.js';
import { summarizeProjectFidelity } from '../interchange/validation/FidelityEvaluator.js';
import { validateCanonicalProject } from '../interchange/validation/CanonicalValidator.js';
import { validateSupports } from '../interchange/validation/SupportValidator.js';
import { validateAnnotations } from '../interchange/validation/AnnotationValidator.js';

const store = createModelExchangeStore();

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderLeftPanel() {
  const source = store.sourcePreview;
  const canonical = store.canonicalPreview;
  return `
    <div class="model-exchange-panel model-exchange-left">
      <div class="model-exchange-section-title">Source Preview</div>
      ${source ? `
        <div><strong>${escapeHtml(source.name)}</strong></div>
        <div>Format: ${escapeHtml(source.format)}</div>
        <div>Dialect: ${escapeHtml(source.dialect)}</div>
        <div>Messages: ${source.messageCount}</div>
      ` : '<div>No source loaded.</div>'}
      <hr>
      <div class="model-exchange-section-title">Canonical Preview</div>
      ${canonical ? canonical.assemblies.map((asm) => `
        <div style="margin-bottom:8px; padding:8px; border:1px solid #243247; border-radius:8px;">
          <div><strong>${escapeHtml(asm.name)}</strong></div>
          <div>Nodes: ${asm.nodes}</div>
          <div>Segments: ${asm.segments}</div>
          <div>Supports: ${asm.supports}</div>
          <div>Annotations: ${asm.annotations}</div>
        </div>
      `).join('') : '<div>No canonical project.</div>'}
    </div>
  `;
}

function renderCenterPanel() {
  const rendered = store.renderedPreview;
  const fidelity = store.project ? summarizeProjectFidelity(store.project) : null;
  return `
    <div class="model-exchange-panel model-exchange-center">
      <div class="model-exchange-toolbar">
        <button class="model-exchange-button" data-action="preview-source">Source Preview</button>
        <button class="model-exchange-button" data-action="preview-canonical">Canonical Preview</button>
        <button class="model-exchange-button" data-action="preview-rendered">Rendered Preview</button>
        <select class="model-exchange-select" data-action="support-mode">
          <option value="SYMBOL">Support: Symbol</option>
          <option value="SIMPLIFIED_GEOMETRY">Support: Simplified Geometry</option>
          <option value="METADATA_ONLY">Support: Metadata Only</option>
        </select>
        <button class="model-exchange-button" data-action="toggle-verification">Verify 100%</button>
      </div>
      <div class="model-exchange-section-title">Rendered Inspector</div>
      ${rendered ? `
        <div class="mx-summary-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-top: 1rem;">
          <div class="mx-card" style="padding: 1rem; border: 1px solid #243247; border-radius: 8px;">
            <strong>Assemblies</strong><br><span style="font-size: 1.5rem; font-weight: bold; color: #1e90ff;">${rendered.assemblies.length}</span>
          </div>
          <div class="mx-card" style="padding: 1rem; border: 1px solid #243247; border-radius: 8px;">
            <strong>Nodes</strong><br><span style="font-size: 1.5rem; font-weight: bold; color: #32cd32;">${rendered.nodes.length}</span>
          </div>
          <div class="mx-card" style="padding: 1rem; border: 1px solid #243247; border-radius: 8px;">
            <strong>Supports</strong><br><span style="font-size: 1.5rem; font-weight: bold; color: #ff8c00;">${rendered.supportRenderItems.length}</span>
          </div>
          <div class="mx-card" style="padding: 1rem; border: 1px solid #243247; border-radius: 8px;">
            <strong>Annotations</strong><br><span style="font-size: 1.5rem; font-weight: bold; color: #8a2be2;">${rendered.annotationRenderItems.length}</span>
          </div>
        </div>
        <div style="margin-top: 1rem;">
          <strong>Fidelity Summary:</strong>
          <pre class="model-exchange-code">${escapeHtml(JSON.stringify(fidelity || {}, null, 2))}</pre>
        </div>
      ` : `<div class="mx-empty" style="margin-top: 1rem; color: #9aa8ba;">No rendered preview available for current source. Please load a project.</div>`}
    </div>
  `;
}

function renderRightPanel() {
  const project = store.project;
  const issues = project ? [
    ...validateCanonicalProject(project),
    ...validateSupports(project),
    ...validateAnnotations(project),
  ] : [];
  return `
    <div class="model-exchange-panel model-exchange-right">
      <div class="model-exchange-section-title">Inspector</div>
      ${project ? `
        <div><strong>${escapeHtml(project.name)}</strong></div>
        <div>Assemblies: ${project.assemblies.length}</div>
        <div>Nodes: ${(project.nodes || []).length}</div>
        <div>Segments: ${(project.segments || []).length}</div>
        <div>Supports: ${(project.supports || []).length}</div>
        <div>Annotations: ${(project.annotations || []).length}</div>
      ` : '<div>No project loaded.</div>'}
      <hr>
      <div class="model-exchange-section-title">Validation</div>
      <div class="model-exchange-code">${escapeHtml(JSON.stringify(issues, null, 2))}</div>
    </div>
  `;
}

function renderBottomPanel() {
  const messages = [
    ...(store.sourceRecord?.messages || []),
    ...(store.project?.diagnostics?.messages || []),
  ];
  return `
    <div class="model-exchange-panel model-exchange-bottom">
      <div class="model-exchange-section-title">Diagnostics / Log</div>
      <div class="model-exchange-code">${escapeHtml(JSON.stringify(messages, null, 2))}</div>
    </div>
  `;
}

function renderRoot(container) {
  container.innerHTML = `
    <div class="model-exchange-root">
      ${renderLeftPanel()}
      ${renderCenterPanel()}
      ${renderRightPanel()}
      ${renderBottomPanel()}
    </div>
  `;

  container.querySelector('[data-action="toggle-verification"]')?.addEventListener('click', () => {
    updateViewState(store, { verificationMode: !store.viewState.verificationMode });
  });
  container.querySelector('[data-action="support-mode"]')?.addEventListener('change', (e) => {
    updateViewState(store, { supportRenderMode: e.target.value });
  });
}

export function createModelExchangeTab(container) {
  store.subscribe(() => renderRoot(container));
  renderRoot(container);
  return {
    async importSource(payload) {
      await importIntoModelExchange(store, payload);
    },
    getStore() {
      return store;
    },
  };
}
